package pw3.ifsp.cli;

import pw3.ifsp.controller.alunoController;

public class AlunoCli {
    public static void main(String[] args) {
        alunoController controler = new alunoController();
        controler.createAluno("bruno","1236","a@a",2.0,3.0,5.0);
    }
}

