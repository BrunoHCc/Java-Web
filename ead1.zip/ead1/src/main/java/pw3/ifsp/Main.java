//package pw3.ifsp;
//
//import jakarta.persistence.EntityManager;
//
//
//import java.util.Scanner;
//
//// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
//// then press Enter. You can now see whitespace characters in your code.
//public class Main {
//    public static void main(String[] args) {
//
//
//        Scanner scanner = new Scanner(System.in);
//
//        int opcao;
//        do {
//            System.out.println("\nEscolha uma opção:" +
//                    "\n1. Cadastrar aluno" +
//                    "\n2. Excluir aluno" +
//                    "\n3. Editar aluno" +
//                    "\n4. Buscar aluno por nome" +
//                    "\n5. Listar todos alunos" +
//                    "\n6. Sair");
//
//            opcao = scanner.nextInt();
//            scanner.nextLine();
//
//            switch (opcao){
//                case 1:
//                    break;
//                default:
//                    throw new IllegalStateException("Unexpected value: " + opcao);
//            }
//
//        } while (opcao != 6);
//    }
//}